package controllers;

import play.*;
import play.mvc.*;
import java.util.*;
import models.*;

@With(Secure.class)
@Check("isAdmin")
public class Users extends CRUD {
 
}