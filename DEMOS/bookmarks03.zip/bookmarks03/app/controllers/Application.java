package controllers;

import play.*;
import play.mvc.*;

import java.util.*;

import models.*;

public class Application extends Controller {

    public static void index() {
	
		String username = session.get("username");
		User user = User.find("select u from User u where u.username = '"+
	                            username+"'").first();
		if(user != null) {
			session.put("username",user.username);
		}
	
		List<Bookmark> bookmarks = Bookmark.findAll();
        render(bookmarks, user);
    }

	public static void bytechno() {
		List<Techno> technos = Techno.findAll();
		render(technos);
	}

}
